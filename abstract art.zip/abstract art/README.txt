the app is located in dist/abstract-art.exe

type how mant lines (how much the turtle goes forward and turns) into the input box then press the 'art' button.