import tkinter as tk
import turtle
from turtle import *
import random

canvas = tk.Canvas(width=500, height=500)
canvas.pack()

entry = tk.Entry()
canvas.create_window(250, 250, window=entry)

def draw():
    numbe = entry.get()
    intnumbe = int(numbe)
    count = 0

    while count < intnumbe:
        turtle.setup(width=10000, height=10000, startx=0, starty=0)
        turtle.bgcolor('black')
        turtle.title("abstract art")
        turtle.speed(125)
        for i in range(1,intnumbe):
            turtle.forward(random.randrange(20, 200))
            turtle.left(random.randrange(10, 170))
            for i in range(random.randrange(1, 5), random.randrange(1, 5)):
                shape = ["turtle",'triangle','square','circle','classic']
                ss = random.choice(shape)
                turtle.shape(ss)
                colors  = ["red","green","blue","orange","purple","pink","yellow","cyan","sky blue"]
                ee = random.choice(colors)
                turtle.color(ee)
                turtle.pensize(random.randrange(1, 5))
                turtle.setx(random.randrange(-600.0, 600.0))
                turtle.sety(random.randrange(-300.0, 300.0))
        turtle.end_fill()
        turtle.exitonclick()
        turtle.done()

button = tk.Button(text="art", bg='pink', fg='black', activebackground="blue", activeforeground="white", command=draw)
canvas.create_window(250, 290, window=button)

canvas.mainloop()